#!/data/data/sd.adaa.codeide/files/usr/bin/sh

echo "$@"
