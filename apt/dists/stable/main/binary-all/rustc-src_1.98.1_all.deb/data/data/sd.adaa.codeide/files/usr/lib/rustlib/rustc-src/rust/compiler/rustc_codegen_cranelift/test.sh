#!/data/data/sd.adaa.codeide/files/usr/bin/sh
exec ./y.sh test "$@"
