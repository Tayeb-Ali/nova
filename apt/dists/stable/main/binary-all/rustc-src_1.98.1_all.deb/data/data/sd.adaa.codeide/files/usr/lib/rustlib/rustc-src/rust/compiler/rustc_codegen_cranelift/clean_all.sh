#!/data/data/sd.adaa.codeide/files/usr/bin/sh
set -e

rm -rf target/ build_system/target download/ build/ dist/
