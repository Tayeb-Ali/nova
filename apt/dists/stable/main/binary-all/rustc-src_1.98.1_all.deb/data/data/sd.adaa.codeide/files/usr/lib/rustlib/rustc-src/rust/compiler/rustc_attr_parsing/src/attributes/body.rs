//! Attributes that can be found in function body.

use rustc_feature::AttributeStability;

use super::prelude::*;

pub(crate) struct CoroutineParser;

impl NoArgsAttributeParser for CoroutineParser {
    const PATH: &[Symbol] = &[sym::coroutine];
    const ALLOWED_TARGETS: AllowedTargets<'_> =
        AllowedTargets::AllowList(&[Allow(Target::Closure)]);
    const STABILITY: AttributeStability = unstable!(coroutines);
    const CREATE: fn(rustc_span::Span) -> AttributeKind = |_| AttributeKind::Coroutine;
}
