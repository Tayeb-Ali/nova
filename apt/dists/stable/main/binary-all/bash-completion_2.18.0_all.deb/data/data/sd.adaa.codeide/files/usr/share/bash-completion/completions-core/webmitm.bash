# webmitm completion

_comp_cmd_webmitm()
{
    local cur prev words cword comp_args
    _comp_initialize -- "$@" || return

    if [[ $cur == -* ]]; then
        _comp_compgen_usage
    else
        _comp_compgen_known_hosts
    fi

} &&
    complete -F _comp_cmd_webmitm webmitm
