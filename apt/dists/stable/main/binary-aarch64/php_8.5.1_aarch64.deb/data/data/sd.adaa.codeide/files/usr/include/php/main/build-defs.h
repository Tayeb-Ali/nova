/*
   +----------------------------------------------------------------------+
   | Copyright (c) The PHP Group                                          |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | https://www.php.net/license/3_01.txt                                 |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Stig Sæther Bakken <ssb@php.net>                             |
   +----------------------------------------------------------------------+
*/

#define CONFIGURE_COMMAND " '/home/ppain/.termux-build/php/src/configure'  '--disable-dependency-tracking' '--prefix=/data/data/sd.adaa.codeide/files/usr' '--libdir=/data/data/sd.adaa.codeide/files/usr/lib' '--includedir=/data/data/sd.adaa.codeide/files/usr/include' '--disable-rpath' '--disable-rpath-hack' '--host=aarch64-linux-android' 'ac_cv_func_res_nsearch=no' 'ac_cv_phpdbg_userfaultfd_writefault=no' 'php_cv_lib_gd_gdImageCreateFromPng=yes' 'php_cv_lib_gd_gdImageCreateFromAvif=yes' 'php_cv_lib_gd_gdImageCreateFromWebp=yes' 'php_cv_lib_gd_gdImageCreateFromJpeg=yes' 'php_cv_lib_gd_gdImageCreateFromBmp=yes' 'php_cv_lib_gd_gdImageCreateFromTga=yes' '--enable-bcmath' '--enable-calendar' '--enable-exif' '--enable-mbstring' '--with-capstone' '--enable-pcntl' '--enable-sockets' '--mandir=/data/data/sd.adaa.codeide/files/usr/share/man' '--with-bz2=/data/data/sd.adaa.codeide/files/usr' '--with-config-file-path=/data/data/sd.adaa.codeide/files/usr/etc/php' '--with-config-file-scan-dir=/data/data/sd.adaa.codeide/files/usr/etc/php/conf.d' '--with-curl=/data/data/sd.adaa.codeide/files/usr' '--with-ldap=shared,/data/data/sd.adaa.codeide/files/usr' '--with-ldap-sasl' '--with-openssl=/data/data/sd.adaa.codeide/files/usr' '--with-readline=/data/data/sd.adaa.codeide/files/usr' '--with-sodium=shared,/data/data/sd.adaa.codeide/files/usr' '--with-zlib' '--with-pgsql=shared,/data/data/sd.adaa.codeide/files/usr' '--with-pdo-pgsql=shared,/data/data/sd.adaa.codeide/files/usr' '--with-mysqli=mysqlnd' '--with-pdo-mysql=mysqlnd' '--with-mysql-sock=/data/data/sd.adaa.codeide/files/usr/tmp/mysqld.sock' '--with-apxs2=/home/ppain/.termux-build/php/tmp/apxs-wrapper.sh' '--with-iconv=/data/data/sd.adaa.codeide/files/usr' '--enable-fpm' '--enable-gd=shared,/data/data/sd.adaa.codeide/files/usr' '--with-external-gd' '--with-external-pcre' '--with-zip' '--with-xsl' '--with-gmp' '--with-ffi' '--with-tidy=/data/data/sd.adaa.codeide/files/usr' '--enable-intl' '--sbindir=/data/data/sd.adaa.codeide/files/usr/bin' '--disable-nls' '--enable-shared' '--enable-static' '--libexecdir=/data/data/sd.adaa.codeide/files/usr/libexec' 'host_alias=aarch64-linux-android' 'PKG_CONFIG=/home/ppain/.termux-build/_cache/android-r29-api-24-v6/bin/pkg-config' 'PKG_CONFIG_LIBDIR=/data/data/sd.adaa.codeide/files/usr/lib/pkgconfig:/data/data/sd.adaa.codeide/files/usr/share/pkgconfig' 'CPP=aarch64-linux-android-cpp' 'EXTENSION_DIR=/data/data/sd.adaa.codeide/files/usr/lib/php'"
#define PHP_PROG_SENDMAIL	"/usr/sbin/sendmail"
#define PEAR_INSTALLDIR         ""
#define PHP_INCLUDE_PATH	".:"
#define PHP_EXTENSION_DIR       "/data/data/sd.adaa.codeide/files/usr/lib/php"
#define PHP_PREFIX              "/data/data/sd.adaa.codeide/files/usr"
#define PHP_BINDIR              "/data/data/sd.adaa.codeide/files/usr/bin"
#define PHP_SBINDIR             "/data/data/sd.adaa.codeide/files/usr/bin"
#define PHP_MANDIR              "/data/data/sd.adaa.codeide/files/usr/share/man"
#define PHP_LIBDIR              "/data/data/sd.adaa.codeide/files/usr/lib"
#define PHP_DATADIR             "/data/data/sd.adaa.codeide/files/usr/share/php"
#define PHP_SYSCONFDIR          "/data/data/sd.adaa.codeide/files/usr/etc"
#define PHP_LOCALSTATEDIR       "/data/data/sd.adaa.codeide/files/usr/var"
#define PHP_CONFIG_FILE_PATH    "/data/data/sd.adaa.codeide/files/usr/etc/php"
#define PHP_CONFIG_FILE_SCAN_DIR    "/data/data/sd.adaa.codeide/files/usr/etc/php/conf.d"
#define PHP_SHLIB_SUFFIX        "so"
#define PHP_SHLIB_EXT_PREFIX    ""
