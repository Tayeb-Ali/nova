set(RESOLV_WRAPPER_LIBRARY /data/data/sd.adaa.codeide/files/usr/lib/libresolv_wrapper.so)
