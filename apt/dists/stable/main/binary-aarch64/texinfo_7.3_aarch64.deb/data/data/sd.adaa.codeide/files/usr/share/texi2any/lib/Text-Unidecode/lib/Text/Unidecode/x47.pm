#  Time-stamp: "2014-07-22 05:15:15 MDT sburke@cpan.org"
$Text::Unidecode::Char[ 0x47 ] = Text::Unidecode::make_placeholder_map();
1;
